package ru.chat.server;

import ru.network.TCPConnection;
import ru.network.TCPConnectionListener;

import java.io.IOException;
import java.net.ServerSocket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/**Создаём класc, описывающий работу сервера, этот класс является "слушателем"*/
public class chatServer implements TCPConnectionListener {

    private static final String serverPath = "server/";

    public static void main(String[] args) {

        new chatServer();
    }

    private final ArrayList<TCPConnection> connections = new ArrayList<>();//список из TCP соединений
    private final ArrayList<String> ListOfFiles = new ArrayList<>();//список файлов
    private final ArrayList<String> history = new ArrayList<>();//история сообщений

    private chatServer() {
        System.out.println("Server running...");
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            while (true) {
                try {
                    new TCPConnection(this, serverSocket.accept());
                } catch (IOException e) {
                    System.out.println("TCPConnection exception: " + e);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public synchronized void onConnectionReady(TCPConnection tcpConnection) {
        connections.add(tcpConnection);
        if (history.size() != 0) {
            for (int i = 0; i < history.size(); i++) {
                tcpConnection.sendString(history.get(i));
            }
        }
        sendToAllConnections("Client connected " + tcpConnection);
        System.out.println("Client connected " + tcpConnection);
        updateActiveConnections();
        if (ListOfFiles.size() != 0) {
            String files = "/docs12";
            for (int j = 0; j < ListOfFiles.size(); j++) {
                files += (ListOfFiles.get(j) + "#");
            }
            tcpConnection.sendString(files);
        }
    }

    @Override
    public synchronized void onReceiveString(TCPConnection tcpConnection, String value) {
        sendToAllConnections(value);
    }

    @Override
    public synchronized void onDisconnect(TCPConnection tcpConnection) {
        connections.remove(tcpConnection);
        sendToAllConnections("Client disconnected " + tcpConnection);
        System.out.println("Client disconnected " + tcpConnection);
        updateActiveConnections();
    }

    @Override
    public synchronized void onException(TCPConnection tcpConnection, Exception e) {
        System.out.println("TCPConnection: " + e);
    }

    @Override
    public synchronized void onReceiveFile(TCPConnection tcpConnection, String fileName) {
        tcpConnection.getFile(serverPath, fileName);
        ListOfFiles.add(fileName);
        updateFileList();
    }

    @Override
    public synchronized void onSendFile(TCPConnection tcpConnection, String fileName) {
        Path path = Paths.get(serverPath + fileName);
        if (Files.exists(path)) {
            tcpConnection.sendFile(serverPath + fileName);
        }
    }

    //при подключении нового пользователя отправляем всем об этом сообщение
    private void sendToAllConnections(String value) {
        history.add(value);
        if (history.size() > 100) {
            if (history.get(0).contains("/01Text")) {
                String[] nvalue = history.get(0).split("#");
                ListOfFiles.remove(nvalue[1]);
                updateFileList();
            }
            history.remove(0);
        }
        int cnt = connections.size();
        for (int i = 0; i < cnt; i++) {
            connections.get(i).sendString(value);
        }
    }

    private void updateFileList() {
        final int cnt = connections.size();
        for (int i = 0; i < cnt; i++) {
            if (ListOfFiles.size() != 0) {
                String files = "/docs12";
                for (int j = 0; j < ListOfFiles.size(); j++) {
                    files += (ListOfFiles.get(j) + "#");
                }
                connections.get(i).sendString(files);
            }
        }

    }

    private void updateActiveConnections() {
        int cnt = connections.size();
        for (int i = 0; i < cnt; i++) {
            String members = "/0users";
            for (int j = 0; j < cnt; j++) {
                members += (connections.get(j) + "#");
            }
            connections.get(i).sendString(members);
        }
    }
}
