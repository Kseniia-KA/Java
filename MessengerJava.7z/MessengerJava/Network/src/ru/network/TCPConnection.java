package ru.network;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**Класс, описывающий работу с TCP соединением*/
public class TCPConnection {
    private final Socket socket;//сокет, который связан с этим TCP сеодинением
    private final Thread rxThread;//поток, который слушает входящее сообщение
    private final TCPConnectionListener eventListener;//слушатель событий
    /*Потоки ввода- вывода*/
    private final DataInputStream in;
    private final DataOutputStream out;

    /***Конструктор, который создаёт сокет "внутри"*/
    public TCPConnection(TCPConnectionListener eventListener, String ipAddr, int port) throws IOException {
        this(eventListener, new Socket(ipAddr, port));
    }
    /**Конструктор, который принимает на вход объект сокета и создаёт соединение с этим сокетом*/
    public TCPConnection(TCPConnectionListener eventListener, Socket socket) throws IOException {
        this.eventListener = eventListener;
        this.socket = socket;
        in = new DataInputStream(socket.getInputStream());
        out = new DataOutputStream(socket.getOutputStream());

        //создаём поток, который слушает входящее соединение
        rxThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    eventListener.onConnectionReady(TCPConnection.this);

                    //получаем строки
                    while (!rxThread.isInterrupted()) {
                        int dataType = in.readInt();

                        if (dataType == 1) {
                            String title = in.readUTF();
                            eventListener.onReceiveFile(TCPConnection.this, title);
                        } else if (dataType == -1){
                            String message = in.readUTF();
                            if (message.contains("/download ")) {
                                eventListener.onSendFile(TCPConnection.this, message.substring(message.indexOf("/download ") + 10));
                            } else {
                                eventListener.onReceiveString(TCPConnection.this, message);
                            }
                        }

                    }

                } catch (IOException e) {
                    eventListener.onException(TCPConnection.this, e);

                } finally {
                    eventListener.onDisconnect(TCPConnection.this);
                }
            }
        });
        rxThread.start();
    }
    //метод отправки сообщения
    public synchronized void sendString(String value) {
        try {
            out.writeInt(-1);
            out.flush();//принудительно передать , убрать из буфера
            out.writeUTF(value);
            out.flush();
        } catch (IOException e) {
            eventListener.onException(TCPConnection.this, e);
            disconnect();
        }
    }


    public synchronized void sendFile(String filepath) {
        try {
            Path path = Paths.get(filepath);
            out.writeInt(1);
            out.writeUTF(path.getFileName().toString());
            out.writeLong(Files.size(path));
            FileInputStream fis = new FileInputStream(path.toFile());
            byte[] buffer = new byte[4096];
            int write = 0;
            int totalWrite = 0;
            long remaining = Files.size(path);
            while ((write = fis.read(buffer, 0, (int) Math.min(buffer.length, remaining))) > 0) {
                totalWrite += write;
                remaining -= write;
                out.write(buffer, 0, write);
            }
            fis.close();
        } catch (IOException e) {
            eventListener.onException(TCPConnection.this, e);
            disconnect();
        }
    }

    public synchronized void getFile(String filepath, String fileName) {
        try {
            Files.createDirectories(Paths.get(filepath));
            FileOutputStream fos = new FileOutputStream(filepath + fileName);
            byte[] buffer = new byte[4096];
            int read = 0;
            int totalRead = 0;
            long remaining = in.readLong();
            while ((read = in.read(buffer, 0, (int) Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                fos.write(buffer, 0, read);
            }
            fos.close();
        } catch (IOException e) {
            eventListener.onException(TCPConnection.this, e);
            disconnect();
        }
    }
    //метод для разрыва сединения
    //методы синхронизированы для безопасного обращения из разных потоков
    public synchronized void disconnect() {
        rxThread.interrupt();
        try {
            socket.close();
        } catch (IOException e) {
            eventListener.onException(TCPConnection.this, e);
        }
    }

    @Override
    public String toString() {
        return "TCPConnection" + socket.getInetAddress() + ": " + socket.getPort();
    }
}
